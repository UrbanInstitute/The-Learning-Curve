#URBAN INSTITUTE

# load R libraries
library(tidyverse)
library(dplyr)
library(tidyr)
library(ggplot2)
library(labelled)
library(urbnthemes)

extrafont::loadfonts()

set_urbn_defaults(style = "print")
# load R data from the directory where this script is saved

rm(list =ls())

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

sixyeargrad = read.csv("Data/Output_Data/hsi_grad_rates.csv")

#################### ADD VALUE LABELS #########################

sixyeargrad2 <- sixyeargrad %>%
  set_value_labels(
    race = c('White' = 1,
             'Black' = 2,
             'Hispanic' = 3,
             'Asian' = 4,
             'American Indian or Native American' = 5,
             'Native Hawaiian or Pacific Islander' = 6,
             'Two or More' = 7,
             'Nonresident' = 8,
             'Unknown' = 9,
             'All' = 99),
    sex = c('Male' = 1,
            'Female' = 2),
    fips = c('Alabama' = 1,
             'Alaska' = 2,
             'American Samoa' = 3,
             'Arizona' = 4,
             'Arkansas' = 5,
             'California' = 6,
             'Canal Zone' = 7,
             'Colorado' = 8,
             'Connecticut' = 9,
             'Delaware' = 10,
             'District of Columbia' = 11,
             'Florida' = 12,
             'Georgia' = 13,
             'Guam' = 14,
             'Hawaii' = 15,
             'Idaho' = 16,
             'Illinois' = 17,
             'Indiana' = 18,
             'Iowa' = 19,
             'Kansas' = 20,
             'Kentucky' = 21,
             'Louisiana' = 22,
             'Maine' = 23,
             'Maryland' = 24,
             'Massachusetts' = 25,
             'Michigan' = 26,
             'Minnesota' = 27,
             'Mississippi' = 28,
             'Missouri' = 29,
             'Montana' = 30,
             'Nebraska' = 31,
             'Nevada' = 32,
             'New Hampshire' = 33,
             'New Jersey' = 34,
             'New Mexico' = 35,
             'New York' = 36,
             'North Carolina' = 37,
             'North Dakota' = 38,
             'Ohio' = 39,
             'Oklahoma' = 40,
             'Oregon' = 41,
             'Pennsylvania' = 42,
             'Puerto Rico' = 43,
             'Rhode Island' = 44,
             'South Carolina' = 45,
             'South Dakota' = 46,
             'Tennessee' = 47,
             'Texas' = 48,
             'Utah' = 49,
             'Vermont' = 50,
             'Virginia' = 51,
             'Virgin Islands of the US' = 52,
             'Washington' = 53,
             'West Virginia' = 54,
             'Wisconsin' = 55,
             'Wyoming' = 56,
             'Department of Defense Dependent Schools (overseas)' = 58,
             'Bureau of Indian Education' = 59,
             'American Samoa' = 60,
             'Department of Defense Dependent Schools (domestic)' = 61,
             'Department of Defense Education Activity' = 63,
             'Federated States of Micronesia' = 64,
             'Mariana Islands waters (including Guam)' = 65,
             'Guam' = 66,
             'Johnston Atoll' = 67,
             'Marshall Islands' = 68,
             'Northern Mariana Islands' = 69,
             'Palau' = 70,
             'Midway Islands' = 71,
             'Puerto Rico' = 72,
             'US Minor Outlying Islands' = 74,
             'Atlantic coast from North Carolina to Florida, and the coasts of Puerto Rico and Virgin Islands' = 75,
             'Navassa Island' = 76,
             'Virgin Islands of the US' = 78,
             'Wake Island' = 79,
             'Baker Island' = 81,
             'Howland Island' = 84,
             'Jarvis Island' = 86,
             'Kingman Reef' = 89,
             'Palmyra Atoll' = 95,
             'Missing/not reported' = -1,
             'Not applicable' = -2,
             'Suppressed data' = -3))

sixyeargrad2$years_since_hsi_des_rev = as.numeric(sixyeargrad2$year) - as.numeric(sixyeargrad2$year_of_HSI_des)

#################### PRE: DESCRIPTIVES #########################
# Frequency count of the variable `by year since HSR designation` (broken by race/ethnicity,sex)
sixyeargrad2 %>% count(years_since_hsi_des_rev)

#have to group by year and race variable, then sum cohort and completer 150pct, then calculate percentage

#group by multiple variables
sixyeargrad2$race = as.numeric(sixyeargrad2$race)
sixyeargrad2$sex = as.numeric(sixyeargrad2$sex)
sixyeargrad2$unitid = as.character(sixyeargrad2$unitid)

freq_by_hsiyr_race <- sixyeargrad2 %>%
  mutate(years_since_hsi_des_rev = as.numeric(years_since_hsi_des_rev))%>%
  filter(years_since_hsi_des_rev>=-5 & years_since_hsi_des_rev<=4)%>%
  group_by(unitid, race, sex) %>%
  mutate(num_years_avail = n()) %>%
  filter(num_years_avail == 10) %>%
  group_by(years_since_hsi_des_rev, race) %>%
  summarize(cohort_sum = sum(cohort_adj_150pct, na.rm = TRUE),
            completersbach_sum = sum(completers_bach_150pct, na.rm = TRUE),
            counts = n()) %>%
  arrange(years_since_hsi_des_rev)

freq_by_hsiyr_race

#calculate 6-year graduation rates by year of HSR designation & race
freq_by_hsiyr_race2 <- freq_by_hsiyr_race %>%
  mutate(six_year_grad_bach = completersbach_sum/cohort_sum)%>%
  group_by(years_since_hsi_des_rev)%>%
  select(-c(completersbach_sum, cohort_sum, counts))%>%
  spread(key = 'race', value = 'six_year_grad_bach')%>%
  rowwise()%>%
  mutate(White_Hispanic_gap = `1`-`3`,
         White_Black_gap = `1`-`2`,
         White_AmericanIndian_gap = `1`-`5`,
         Asian_Hispanic_gap = `4`-`3`,
         Asian_Black_gap = `4`-`2`,
         Asian_AmericanIndian_gap = `4`-`5`)

freq_by_hsiyr_race2

#calculate cohort counts by year of HSI designation & race
freq_by_hsiyr_race3 <- freq_by_hsiyr_race %>%
  select(-c(completersbach_sum, counts)) %>%
  group_by(years_since_hsi_des_rev, race) %>%
  spread(key = 'race', value = 'cohort_sum') %>%
  rowwise()

freq_by_hsiyr_race3

#Figure 1 (Cohort counts by year of HSI designation & race)

jpeg("Data/Output_Data/fig_1.jpeg", width = 700, height = 700)
p1 = freq_by_hsiyr_race3 %>% 
  ggplot(mapping = aes(x=years_since_hsi_des_rev)) +
  ylab('First-time freshmen cohort counts') + xlab('Year of HSI designation') + 
  geom_line(aes(y = `1`,color = 'White'))+
  geom_line(aes(y = `2`,color = 'Black'))+
  geom_line(aes(y = `3`,color = 'Hispanic'))+
  geom_line(aes(y = `4` , color = 'Asian'))+
  geom_line(aes(y = `5` , color = 'Native American'))+
  geom_line(aes(y = `8` , color = 'Nonresident'))+
  scale_x_continuous(breaks = seq(-5,4, by=1))+
  scale_y_continuous(breaks = c(0, 20000, 40000, 60000),
                     limits = c(0, 70000),
                     labels = c("0", "20,000", "40,000", "60,000"))+
  theme(
    legend.text = element_text(size = 16),
    axis.title.x = element_text(size = 14),
    axis.title.y = element_text(size = 14)
  )
print(p1)
dev.off()

#Figure 2 (6-year graduation rates by year of HSI designation & race)
jpeg("Data/Output_Data/fig_2.jpeg", width = 700, height = 700)
p2 = freq_by_hsiyr_race2 %>% 
  ggplot(mapping = aes(x=years_since_hsi_des_rev)) +
  ylab('Six-year graduation rate') + xlab('Year of HSI designation') + 
  geom_line(aes(y = `1`,color = 'White'))+
  geom_line(aes(y = `2`,color = 'Black'))+
  geom_line(aes(y = `3`,color = 'Hispanic'))+
  geom_line(aes(y = `4` , color = 'Asian'))+
  geom_line(aes(y = `5` , color = 'Native American'))+
  geom_line(aes(y = `8` , color = 'Nonresident'))+
  scale_x_continuous(breaks = seq(-5,4, by=1))+
  scale_y_continuous(breaks = c(0, .2, .4, .6),
                     limits = c(0, .7),
                     labels = c("0%", "20%", "40%", "60%"))+
  theme(
    legend.text = element_text(size = 16),
    axis.title.x = element_text(size = 14),
    axis.title.y = element_text(size = 14)
  )
print(p2)
dev.off()

#Figure 3 (6-year graduation rate gaps by race)
jpeg("Data/Output_Data/fig_3.jpeg", width = 700, height = 700)
p3 = freq_by_hsiyr_race2 %>% 
  ggplot(mapping = aes(x=years_since_hsi_des_rev)) +
  ylab('Six-year graduation rate') + xlab('Year of HSI designation') + 
  geom_line(aes(y = `White_Hispanic_gap`,color = 'White Hispanic gap'))+
  geom_line(aes(y = `White_Black_gap`,color = 'White-Black gap'))+
  geom_line(aes(y = `Asian_Hispanic_gap` , color = 'Asian-Hispanic gap'))+
  geom_line(aes(y = `Asian_Black_gap` , color = 'Asian-Black gap'))+
  scale_x_continuous(breaks = seq(-5,4, by=1))+
  scale_y_continuous(breaks = c(0, .1, .2),
                     limits = c(0, .25),
                     labels = c("0%", "10%", "20%"))+
  theme(
    legend.text = element_text(size = 16),
    axis.title.x = element_text(size = 14),
    axis.title.y = element_text(size = 14)
  )
print(p3)
dev.off()