library(tidyverse)
library(haven)
library(data.table)

# Clear your data library
rm(list=ls())

# Check your working directory
# Ultimate data storage of Zip contents
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

output_folder =  "Data/Built"
raw_folder =  "Data/Raw"

for(i in c(output_folder,raw_folder)){
  if(!dir.exists(output_folder)){
    dir.create(file.path(getwd(),output_folder),recursive = T)
  }
}

do.call(file.remove, list(list.files("Data/Raw", full.names = TRUE)))
do.call(file.remove, list(list.files("Dictionaries", full.names = TRUE)))
# gathering URLs from the NSF website

current_year = 2021
start_year = 2004

years = start_year:current_year

url_head = "https://nces.ed.gov/ipeds/datacenter/data/GR"

my_urls = sort(paste0(url_head, years,"_l2.zip"))
my_dicts = sort(paste0(url_head, years,"_l2_DICT.zip"))

tempStore = vector(mode = 'list',length = length(years))

# List for holding data
Collected_Data = vector(mode = 'list',length = length(years))


for (i in 1:length(years)){
  tempStore[[i]] = tempfile()
  u = my_urls[i]
  y = my_dicts[i]
  f1 = paste0("[Gg][Rr]",sprintf("%04d",years[i]),"_[Ll]2.csv")
  f2 = paste0("[Gg][Rr]",sprintf("%04d",years[i]),"_[Ll]2_[Rr][Vv].csv")
  f1_a = paste0("Data/Raw/GR",sprintf("%04d",years[i]-1),"_L2.csv")
  f2_a = paste0("Data/Raw/GR",sprintf("%04d",years[i]-1),"_L2_RV.csv")
  if(years[i]>=2009&years[i]<=2012){
    f3 = paste0("[Gg][Rr]",sprintf("%04d",years[i]),"_l2.xls")
    f3_a = paste0("Dictionaries/GR",sprintf("%04d",years[i]-1),"_L2.xls")
  }else{
    f3 = paste0("[Gg][Rr]",sprintf("%04d",years[i]),"_l2.xlsx")
    f3_a = paste0("Dictionaries/GR",sprintf("%04d",years[i]-1),"_L2.xlsx")
  }
  download.file(
    url = u,
    destfile = tempStore[[i]])
  unzip(
    zipfile =
      tempStore[[i]],
    files = NULL,
    exdir = "Data/Raw"
  )
  download.file(
    url = y,
    destfile = tempStore[[i]])
  unzip(
    zipfile =
      tempStore[[i]],
    files = NULL,
    exdir = "Dictionaries"
  )
  file.rename(from = paste0("Data/Raw/",list.files("Data/Raw")[
    grep(f1,
         list.files("Data/Raw"))]),
    to = f1_a)
  file.rename(from = paste0("Dictionaries/",list.files("Dictionaries")[grep(f3,list.files("Dictionaries"))]),
              to = f3_a)
  try(
    file.rename(from = paste0("Data/Raw/",list.files("Data/Raw")[
      grep(f2,
           list.files("Data/Raw"))]),
      to = f2_a)
  )
  if(file.exists(f2_a)){
    Collected_Data[[i]] = read.csv(f2_a)
  }else{
    Collected_Data[[i]] = read.csv(f1_a)
  }
  Collected_Data[[i]]$year = years[i]-1
  colnames(Collected_Data[[i]]) = tolower(colnames(Collected_Data[[i]]))
  Collected_Data[[i]]$sex = 99
  Collected_Data[[i]]$race = 99
  Collected_Data[[i]]$cohort = 5
  Collected_Data[[i]]$section = 4
  Collected_Data[[i]] = Collected_Data[[i]]%>%
    select(-starts_with("x"))
}

l2_grad_rates = bind_rows(Collected_Data[1:length(years)])%>%
  rename(rev_cohort = line_10,
         exclusions=line_45,
         adj_cohort=line_50,
         completers_prog_sub_2yr_100pct=line_55,
         completers_prog_sub_2yr_150pct=line_11,
         transfers=line_30,
         still_enrolled=line_51,
         not_enrolled_anymore=line_52,
         sub_2yr_pell_rev_cohort=pglin10,
         sub_2yr_pell_exclusions=pglin45,
         sub_2yr_pell_adj_cohort=pglin50,
         sub_2yr_pell_150pct=pglin11,
         sub_2yr_stafford_no_pell_rev_cohort=sslin10,
         sub_2yr_stafford_no_pell_exclusions=sslin45,
         sub_2yr_stafford_no_pell_adj_cohort=sslin50,
         sub_2yr_stafford_no_pell_150pct=sslin11,
         sub_2yr_no_stafford_no_pell_rev_cohort=nrlin10,
         sub_2yr_no_stafford_no_pell_exclusions=nrlin45,
         sub_2yr_no_stafford_no_pell_adj_cohort=nrlin50,
         sub_2yr_no_stafford_no_pell_150pct=nrlin11
  )%>%
  dplyr::relocate(unitid, year, race, sex)%>%
  dplyr::arrange(unitid, year)

write.csv(l2_grad_rates,paste0("Data/Built/l2_gr_2004_",current_year-1,".csv"), row.names = F)
