library(tidyverse)
library(data.table)
library(educationdata)
library(readxl)

rm(list =ls())

dire = dirname(rstudioapi::getActiveDocumentContext()$path)
try({setwd(dire)})

recent_year = 2021

current_year = recent_year - 1
start_year = 1996


output_folder =  "Data/Output_Data"
raw_folder =  "Data/Raw"
int_folder =  "Data/Intermediate"
dict_folder =  "Dictionaries"

grad_rates_150 = data.table::fread(paste0("Data/Output_Data/GR_1996_",current_year,"_3.csv")) %>%
  filter(subcohort%in%c(99,-2))
grad_rates_200  = data.table::fread("https://educationdata.urban.org/csv/ipeds/colleges_ipeds_grad-rates-200pct.csv")%>%
  mutate(race = 99,
         sex = 99)%>%
  rename(completers_100pct_new = completers_100pct,
         completers_150pct_new = completers_150pct,
         cohort_adj_150pct_new = cohort_adj_150pct,
         completion_rate_150pct_new = completion_rate_150pct,
         cohort_rev_new = cohort_rev,
         cohort_year_200pct = cohort_year,
         exclusions_new = exclusions)%>%
  select(-institution_level)

fin_data = merge(grad_rates_150, grad_rates_200, by = c("unitid", "year","fips",
                                                        "race", "sex"), all = T)



HSIs = read_excel(
  "3a_UI_original_data.xlsx",
  sheet = "Original Data")
HSIs = HSIs %>%
  select(UnitID, `HSI Year of Designation`)%>%
  rename(unitid = UnitID,
         year_x = `HSI Year of Designation`)

fin_data = merge(fin_data, HSIs, by = "unitid", all = T)
fin_data$years_since_HSI_des = fin_data$year - fin_data$year_x

fin_data_2 = fin_data[which(!is.na(fin_data$year_x)),]%>%
  select(-c(cohort, section))%>%
  select(unitid, inst_name,
         year, fips,
         race, sex, cohort_adj_150pct,
         completers_bach_150pct,
         completers_bach_100pct,
         completers_200pct,
         completers_150pct,
         completers_100pct,
         completion_rate_200pct,
         completion_rate_150pct,
         completion_rate_100pct,
         year_x,
         years_since_HSI_des)%>%
  rename(year_of_HSI_des= year_x)%>%
  filter(year!= 2020)

fin_data_2$inst_name[fin_data_2$unitid==448886] = "Arizona State University-Downtown Phoenix"
fin_data_2$inst_name[fin_data_2$unitid==487296] = "University of Arizona-Sierra Vista"
fin_data_2$inst_name[fin_data_2$unitid==459949] = "Texas A&M University-San Antonio"
fin_data_2$inst_name[fin_data_2$unitid==407009] = "Arizona State University-West"

fin_data_2 = fin_data_2 %>%
  select(-ends_with("100pct"))

write_csv(fin_data_2, "Data/Output_Data/hsi_grad_rates.csv")