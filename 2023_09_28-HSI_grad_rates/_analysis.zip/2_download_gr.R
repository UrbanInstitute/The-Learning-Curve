## Should run if L2 Institutions are saved in the same outputs
## folder

library(tidyverse)
library(haven)
library(data.table)

# Clear your data library
rm(list = ls())

# Check your working directory
# Ultimate data storage of Zip contents
dire = dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(dire)

output_folder =  "Data/Output_Data"
built_folder =  "Data/Built"
raw_folder =  "Data/Raw"
int_folder =  "Data/Intermediate"
dict_folder =  "Dictionaries"

do.call(file.remove, list(list.files(raw_folder,
                                     full.names = TRUE)[grepl(".csv",
                                                              list.files(raw_folder,
                                                                         full.names = TRUE))]))
do.call(file.remove, list(list.files(raw_folder,
                                     full.names = TRUE)[!grepl(".zip",
                                                               list.files(raw_folder,
                                                                          full.names = TRUE))]))
# Create dictionary and data folders
for (i in c(output_folder, raw_folder, int_folder, dict_folder)) {
  if (!dir.exists(i)) {
    dir.create(file.path(getwd(), i),
               recursive = T)
  }
}

# Specify year of downloads
recent_year = 2021

current_year = recent_year - 1
start_year = 1996

years = start_year:current_year

url_head = "https://nces.ed.gov/ipeds/datacenter/data/GR"

my_urls = sort(paste0(url_head, years + 1, ".zip"))
my_dicts = sort(paste0(url_head, years + 1, "_DICT.zip"))

# List for holding data
Collected_Data = vector(mode = 'list', length = length(years))
Collected_Data_2 = vector(mode = 'list', length = length(years))

# Downloading data
for (i in 1:length(years)) {
  # Creates a temp file
  u = my_urls[i]
  y = my_dicts[i]
  
  # How Zips should be downloaded
  dat_zip = paste0(raw_folder, "/GR", years[i] + 1, ".zip")
  dict_zip = paste0(dict_folder, "/GR", years[i] + 1, ".zip")
  
  # The name formats of files contained within zip files
  f1 = paste0("[Gg][Rr]",sprintf("%04d",years[i]+1),".csv")
  f2 = paste0("[Gg][Rr]",sprintf("%04d",years[i]+1),"_[Rr][Vv].csv")
  f1_a = paste0("Data/Raw/GR",sprintf("%04d",years[i]),".csv")
  f2_a = paste0("Data/Raw/GR",sprintf("%04d",years[i]),"_RV.csv")
  
  # The various ways that dictionary file names have changed over
  # time
  if(years[i]<2004){
    f3 = paste0("[Gg][Rr]",sprintf("%04d",years[i]+1),".html")
    f3_a = paste0(dict_folder,"/GR",sprintf("%04d",years[i]),".html")
  }else if(years[i]>=2009&years[i]<=2012){
    f3 = paste0("[Gg][Rr]",sprintf("%04d",years[i]+1),".xls")
    f3_a = paste0(dict_folder,"/GR",sprintf("%04d",years[i]),".xls")
  }else{
    f3 = paste0("[Gg][Rr]",sprintf("%04d",years[i]+1),".xlsx")
    f3_a = paste0(dict_folder,"/GR",sprintf("%04d",years[i]),".xlsx")
  }
  
  # Conditionally downloading/replacing zip files
  if(!(file.exists(dat_zip))){
    download.file(
      url = u,
      destfile = dat_zip)
    download.file(
      url = y,
      destfile = dict_zip)
  }
  # Unzipping contents of files
  unzip(
    zipfile =
      dat_zip,
    files = NULL,
    exdir = raw_folder, overwrite = T
  )
  unzip(
    zipfile =
      paste0(dict_folder,"/GR",years[i]+1,".zip"),
    files = NULL,
    exdir = dict_folder, overwrite = T
  )
  
  # Renaming the decompressed contents of the above files
  file.rename(from = paste0(raw_folder,"/",list.files(raw_folder)[
    grep(f1,
         list.files(raw_folder))]),
    to = f1_a)
  file.rename(from = paste0(dict_folder,"/",
                            list.files("Dictionaries")[grep(f3,
                                                            list.files(
                                                              dict_folder)
                            )]),
              to = f3_a)
  try(
    file.rename(from = paste0(raw_folder,"/",
                              list.files(raw_folder)[
                                grep(f2,
                                     list.files(raw_folder))]),
                to = f2_a)
  )
}

# Loading in <2 year program data, since it's not particularly large
l2_data = read.csv(paste0(
  built_folder,
  "/l2_gr_2004_",current_year,".csv"))
crosswalk = read_csv("2a_line_chrtstat_crosswalk.csv")


for(i in 1:length(years)){
  # Loading in data and cleaning up column names
  # i = 5
  f1_a = paste0("Data/Raw/GR",sprintf("%04d",years[i]),".csv")
  f2_a = paste0("Data/Raw/GR",sprintf("%04d",years[i]),"_RV.csv")
  if(file.exists(f2_a)){
    data = read.csv(f2_a)
  }else{
    data = read.csv(f1_a)
  }
  data$year = years[i]
  colnames(data) = tolower(colnames(data)) # setting to lowercase
  data = data%>%
    dplyr::select(-starts_with("x")) # dropping missingness columns
  data$chrtstat = ifelse(data$chrtstat == 0, NA, data$chrtstat) # correcting for cohort stat
  
  # Adding in variable names to spread later
  
  if(!(years[i] %in% c(2009))){
    data_1 = merge(data, crosswalk[c("chrtstat_2", "line_2")], by.x = "line",
                   by.y = "line_2",
                   all = T)
    data_1$chrtstat = ifelse((is.na(data_1$chrtstat)|data_1$chrtstat==""),data_1$chrtstat_2, data_1$chrtstat)
    data_1 = merge(data_1, crosswalk[c("chrtstat_2", "var_name")], by.x = "chrtstat",
                   by.y = "chrtstat_2",
                   all = T) %>%
      dplyr::select(-chrtstat_2)
  }else{
    data_1 = merge(data, crosswalk[c("chrtstat_2", "var_name")], by.x = "chrtstat",
                   by.y = "chrtstat_2",
                   all = T)
  }
  if(years[i] %in% c(2002)){
    data_1$cohort[which((data_1$cohort!=data_1$section)&(data_1$cohort!=5))] = 3
  }
  
  data = data_1
  
  # Checking to see the number of missing chrtstat observations
  print(paste0(years[i], ", Number of missing chrtstat: ", sum(is.na(data$chrtstat))))
  print(paste0(years[i], ", Number of var_name: ", sum(is.na(data$var_name))))
  # Switching from wide to long with gender information
  if(years[i] %in% 1996:2006){
    Data_store_2 = data %>%
      gather(key = "demographic",
             value = "count",contains("gr")&!contains("grtype"))
    
    Data_store_2$demographic = as.numeric(gsub("grrace","", Data_store_2$demographic))
    Data_store_2$sex = NA
    Data_store_2$race = NA
    
    Data_store_2$sex[Data_store_2$demographic%in%c(seq(1,15,2))]=1
    Data_store_2$sex[Data_store_2$demographic%in%c(seq(2,16,2))]=2
    Data_store_2$sex[Data_store_2$demographic%in%c(17:24)]=99
    
    Data_store_2$race[Data_store_2$demographic%in%c(11,12,22)]=1
    Data_store_2$race[Data_store_2$demographic%in%c(3,4,18)]=2
    Data_store_2$race[Data_store_2$demographic%in%c(9,10,21)]=3
    Data_store_2$race[Data_store_2$demographic%in%c(7,8,20)]=4
    Data_store_2$race[Data_store_2$demographic%in%c(5,6,19)]=5
    Data_store_2$race[Data_store_2$demographic%in%c(1,2,17)]=8
    Data_store_2$race[Data_store_2$demographic%in%c(13,14,23)]=9
    Data_store_2$race[Data_store_2$demographic%in%c(15,16,24)]=99
  }else if(years[i] %in% 2007:2009){
    Data_store_2 = data %>%
      gather(key = "demographic",
             value = "count",contains("gr")&!contains("grtype"))
    
    Data_store_2$sex = NA
    Data_store_2$race = NA
    Data_store_2$demographic_version = NA
    
    # There are different version of "demographics"
    # adopted in 2009-2011, so I need to be careful with the versioning
    Data_store_2$demographic_version[grep("^staff",Data_store_2$demographic)]=1
    Data_store_2$demographic_version[grep("^gr",Data_store_2$demographic)]=2
    Data_store_2$demographic_version[grep("^dv",Data_store_2$demographic)]=3
    
    Data_store_2$sex[grepl(".*m$",Data_store_2$demographic)|
                       Data_store_2$demographic %in% paste0("grrace",
                                                            sprintf(
                                                              "%02d",
                                                              c(5, 7, 3, 9, 11)))] = 1
    Data_store_2$sex[grepl(".*w$",Data_store_2$demographic)|
                       Data_store_2$demographic %in% paste0("grrace",
                                                            sprintf(
                                                              "%02d",
                                                              c(6, 8, 4, 10, 12)))] = 2
    Data_store_2$sex[grepl(".*t$",Data_store_2$demographic)|
                       Data_store_2$demographic %in% paste0("grrace",
                                                            sprintf(
                                                              "%02d",
                                                              c(19, 20, 18, 21, 22)))] = 99
    
    Data_store_2$race[grepl("((grwhit)|(dvgrwh))[twm]$",Data_store_2$demographic)|
                        Data_store_2$demographic %in% paste0("grrace",
                                                             sprintf(
                                                               "%02d",
                                                               c(22,11,12)))]=1
    Data_store_2$race[grepl("((grbkaa)|(dvgrbk))[twm]$",Data_store_2$demographic)|
                        Data_store_2$demographic %in% paste0("grrace",
                                                             sprintf(
                                                               "%02d",
                                                               c(18,03,04)))]=2
    Data_store_2$race[grepl("((grhisp)|(dvgrhs))[twm]$",Data_store_2$demographic)|
                        Data_store_2$demographic %in% paste0("grrace",
                                                             sprintf(
                                                               "%02d",
                                                               c(21,09,10)))]=3
    Data_store_2$race[grepl("((grasia)|(dvgrap))[twm]$",Data_store_2$demographic)|
                        Data_store_2$demographic %in% paste0("grrace",
                                                             sprintf(
                                                               "%02d",
                                                               c(20,07,08)))]=4
    Data_store_2$race[grepl("((graian)|(dvgrai))[twm]$",Data_store_2$demographic)|
                        Data_store_2$demographic %in% paste0("grrace",
                                                             sprintf(
                                                               "%02d",
                                                               c(19,06,05)))]=5
    Data_store_2$race[grep("^(grnhpi)[twm]$",Data_store_2$demographic)]=6
    Data_store_2$race[grep("^(gr2mor)[twm]$",Data_store_2$demographic)]=7
    Data_store_2$race[grep("^(grnral)[twm]$",Data_store_2$demographic)]=8
    Data_store_2$race[grep("^(grunkn)[twm]$",Data_store_2$demographic)]=9
    Data_store_2$race[grep("^(grtotl)[twm]$",Data_store_2$demographic)]=99
    Data_store_2 = Data_store_2[
      (Data_store_2$race%in%c(1:5)&Data_store_2$demographic_version==3)|
        (Data_store_2$race%in%c(6:9)&Data_store_2$demographic_version==2)|
        (Data_store_2$race==99),]%>%
      select(-demographic_version)
  }else{
    Data_store_2 = data %>%
      gather(key = "demographic",
             value = "count",starts_with("gr")&!contains("grtype"))
    
    Data_store_2$demographic = gsub("^gr","", Data_store_2$demographic)
    Data_store_2$sex = NA
    Data_store_2$race = NA
    
    Data_store_2$sex[grep("^[a-z0-9]{4}m",Data_store_2$demographic)]=1
    Data_store_2$sex[grep("^[a-z0-9]{4}w",Data_store_2$demographic)]=2
    Data_store_2$sex[grep("^[a-z0-9]{4}t",Data_store_2$demographic)]=99
    
    Data_store_2$race[grep("^whit",Data_store_2$demographic)]=1
    Data_store_2$race[grep("^bkaa",Data_store_2$demographic)]=2
    Data_store_2$race[grep("^hisp",Data_store_2$demographic)]=3
    Data_store_2$race[grep("^asia",Data_store_2$demographic)]=4
    Data_store_2$race[grep("^aian",Data_store_2$demographic)]=5
    Data_store_2$race[grep("^nhpi",Data_store_2$demographic)]=6
    Data_store_2$race[grep("^2mor",Data_store_2$demographic)]=7
    Data_store_2$race[grep("^nral",Data_store_2$demographic)]=8
    Data_store_2$race[grep("^unkn",Data_store_2$demographic)]=9
    Data_store_2$race[grep("^totl",Data_store_2$demographic)]=99
  }
  Data_store_2= Data_store_2%>%
    select(-c("demographic"))
  write.csv(Data_store_2, paste0("Data/Intermediate/GR",years[i],"_part1.csv"), row.names = F)
  rm("data","data_1", "Data_store_2")
}

# get the most frequently occurring duplicate observation
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}


# Creating the Cohort Tables
cohorts = 1:5
for(i in 1:length(years)){
  # i = 1
  data = read.csv(paste0("Data/Intermediate/GR",years[i],"_part1.csv"))
  if(years[i]%in%c(2009)){
    data = data%>%
      select(-c(chrtstat, grtype))
  }else{
    data = data %>%
      select(-c(chrtstat, line, grtype))
  }
  for (j in cohorts){
    if(j == 1){
      S1 = data[data$cohort == j,]
      inst_4yr = S1%>%
        ungroup()%>%
        group_by(unitid, year, cohort, race, sex, section, var_name)%>%
        mutate(dupe = n()>1)
      inst_4yr_dupe= inst_4yr%>%
        filter(dupe == T)%>%
        select(-dupe)%>%
        summarize(count = getmode(count))
      inst_4yr = inst_4yr%>%
        filter(dupe == F)%>%
        select(-dupe)
      inst_4yr = bind_rows(inst_4yr, inst_4yr_dupe)%>%
        spread("var_name", "count")
    }else if(j == 2){
      S1 = data[data$cohort == j,] # reshaping wide
      bach = S1%>%
        ungroup()%>%
        group_by(unitid, year, cohort, race, sex, section, var_name)%>%
        mutate(dupe = n()>1)
      bach_dupe= bach%>%
        filter(dupe == T)%>%
        select(-dupe)%>%
        summarize(count = getmode(count))
      bach = bach%>%
        filter(dupe == F)%>%
        select(-dupe)
      bach = bind_rows(bach, bach_dupe)%>%
        spread("var_name", "count")
    }else if(j == 3){
      S1 = data[data$cohort == j,]
      other = S1%>%
        ungroup()%>%
        group_by(unitid, year, cohort, race, sex, section, var_name)%>%
        mutate(dupe = n()>1)
      other_dupe= other%>%
        filter(dupe == T)%>%
        select(-dupe)%>%
        summarize(count = getmode(count))
      other = other%>%
        filter(dupe == F)%>%
        select(-dupe)
      other = bind_rows(other, other_dupe)%>%
        spread("var_name", "count")
    }else if(j == 4){
      S1 = data[data$cohort == j,] # identifying duplicates
      inst_2yr = S1%>%
        ungroup()%>%
        group_by(unitid, year, cohort, race, sex, section, var_name)%>%
        mutate(dupe = n()>1) # check to see if there are duplicates
      inst_2yr_dupe= inst_2yr%>%
        filter(dupe == T)%>%
        select(-dupe)%>%
        summarize(count = getmode(count))
      inst_2yr = inst_2yr%>%
        filter(dupe == F)%>%
        select(-dupe)
      inst_2yr = bind_rows(inst_2yr, inst_2yr_dupe)%>% # reshaping wide
        spread("var_name", "count")
    }else if(j == 5){
      if(years[i]<2004){
        S1 = data[data$cohort == j,]
        l2 = S1%>%
          ungroup()%>%
          group_by(unitid, year, cohort, race, sex, section, var_name)%>%
          mutate(dupe = n()>1)
        l2_dupe= l2%>%
          filter(dupe == T)%>%
          select(-dupe)%>%
          summarize(count = getmode(count))
        l2 = l2%>% # reshaping wide
          filter(dupe == F)%>%
          select(-dupe)
        l2 = bind_rows(l2, l2_dupe)%>%
          spread("var_name", "count")
      }else if(years[i]>=2004&years[i]<2010){
        l2 = l2_data[l2_data$year==years[i],]
        l2 = l2[c("unitid","year",
                  "race","sex",
                  "rev_cohort","exclusions",
                  "adj_cohort","completers_prog_sub_2yr_150pct",
                  "transfers",
                  "still_enrolled",
                  "cohort", "completers_prog_sub_2yr_100pct")]
      }else if(years[i]>=2010){
        l2 = l2_data[l2_data$year==years[i],]
        l2 = l2[c("unitid","year",
                  "race","sex",
                  "rev_cohort","exclusions",
                  "adj_cohort","completers_prog_sub_2yr_150pct",
                  "transfers",
                  "still_enrolled",
                  "not_enrolled_anymore",
                  "cohort", "completers_prog_sub_2yr_100pct")]
      }
    }
  }
  # converting everything to character for ease
  l2 = lapply(l2, FUN = as.character)
  bach = lapply(bach, FUN = as.character)
  other = lapply(other, FUN = as.character)
  inst_2yr = lapply(inst_2yr, FUN = as.character)
  inst_4yr = lapply(inst_4yr, FUN = as.character)
  data = bind_rows(inst_4yr,bach,other,inst_2yr, l2)
  # Saving to intermediate
  write.csv(data, paste0("Data/Intermediate/GR",years[i],"_part2.csv"), row.names = F)
  print(paste(years[i], ": Step 2 has finished"))
}

rm(inst_4yr,bach,other,inst_2yr, l2,data)

# Appending all years into one DF

for(i in 1:length(years)){
  Collected_Data[[i]] = read.csv(paste0("Data/Intermediate/GR",years[i],"_part2.csv"))
  Collected_Data[[i]] = as.data.frame(sapply(Collected_Data[[i]], FUN = as.character, simplify = T))
}

final_data = bind_rows(Collected_Data[1:length(Collected_Data)])%>%
  rowwise()%>%
  mutate(completers_bach2_150pct = sum(as.numeric(completers_bach_4yr),
                                       as.numeric(completers_bach_5yr),
                                       as.numeric(completers_bach_6yr)
                                       ,na.rm = T))%>%
  rename(completers_bach_100pct = completers_bach_4yr) %>%
  mutate(
    completers_bach3_150pct = max(completers_bach2_150pct, completers_bach_150pct),
    completers_prog2_150pct = sum(as.numeric(completers_bach3_150pct),
                                  as.numeric(completers_prog_2yr_sub_4yr_150_pct),
                                  as.numeric(completers_prog_sub_2yr_150pct),
                                  na.rm = T),
    completers_prog_sub_2yr_100pct = as.numeric(completers_prog_sub_2yr_100pct),
    completers_prog_2yr_sub_4yr_100pct = as.numeric(completers_prog_2yr_sub_4yr_100pct),
    completers_prog2_100pct = sum(as.numeric(completers_bach_100pct),
                                  as.numeric(completers_prog_sub_2yr_100pct),
                                  as.numeric(completers_prog_2yr_sub_4yr_100pct),
                                  na.rm = T),
    completers_prog2_150pct = ifelse(cohort == 1,
                                     as.numeric(completers_prog_150pct),
                                     as.numeric(completers_prog2_150pct)))

final_data_2 = final_data%>%
  select(unitid, section, cohort, year, sex, race,
         adj_cohort, rev_cohort, exclusions,
         not_enrolled_anymore,
         still_enrolled, transfers, starts_with("completers"))

final_data_2$subcohort = NA
final_data_2$subcohort[final_data_2$cohort==1] = 99
final_data_2$subcohort[final_data_2$cohort==2] = 1
final_data_2$subcohort[final_data_2$cohort==3] = 2
final_data_2$subcohort[final_data_2$cohort%in%c(4,5)] = -2

dir = data.table::fread("https://educationdata.urban.org/csv/ipeds/colleges_ipeds_directory.csv")%>%
  filter(year %in% c(years,recent_year))%>%
  select(unitid,year,fips,
         institution_level, inst_name)%>%
  mutate(year = year-1)

fd = merge(final_data_2, dir, by= c("unitid","year"), all.x = T)%>%
  select(-completers_bach2_150pct)

fd_1 = fd[which(fd$cohort%in%c(2,3)),]%>%
  mutate(across(.cols = c(adj_cohort, rev_cohort, exclusions,
                          not_enrolled_anymore, still_enrolled, transfers,
                          starts_with("completers")),.fns = as.numeric))%>%
  group_by(unitid, fips, year,  sex, race, inst_name)%>%
  summarise(across(.cols = c(adj_cohort, rev_cohort, exclusions,
                             not_enrolled_anymore, still_enrolled, transfers,
                             starts_with("completers")),.fns = ~sum(.,na.rm = T)))%>%
  ungroup()%>%
  mutate(cohort = 1,
         section = 1,
         subcohort = 99)

fd_2 = fd[which(fd$cohort!=1),]%>%
  mutate(across(.cols = c(adj_cohort, rev_cohort, exclusions,
                          not_enrolled_anymore, still_enrolled, transfers,
                          starts_with("completers")),.fns = as.numeric))

fd_3 = fd[which(fd$cohort==1),]%>%
  select(unitid, fips, year, race, sex, inst_name,
         institution_level, cohort, section, subcohort, completers_prog2_150pct)

colnames(fd_3)[grep("^completers",colnames(fd_3))] = 
  paste0(colnames(fd_3)[grep("^completers",colnames(fd_3))],"_old")

fd_4 = merge(fd_3, fd_1, by = c("unitid", "fips","year", "cohort", "section", "subcohort",
                                "race", "sex", "inst_name"), all =T)%>%
  mutate(completers_prog2_150pct_fin = completers_prog_150pct)

fd_4$completers_prog2_150pct_fin[is.na(fd_4$completers_prog2_150pct_fin)] = 
  fd_4$completers_prog2_150pct_old[is.na(fd_4$completers_prog2_150pct_fin)]

fd_4$completers_prog2_150pct_fin[is.na(fd_4$completers_prog2_150pct_fin)] = 
  fd_4$completers_prog2_150pct[is.na(fd_4$completers_prog2_150pct_fin)]

fd_4 = fd_4%>%
  select(-c(completers_prog2_150pct, completers_prog2_150pct_old))%>%
  rename(completers_prog2_150pct = completers_prog2_150pct_fin)

fd_2$section = as.character(fd_2$section)
fd_4$section = as.character(fd_4$section)

fd_2$completers_prog_150pct = as.numeric(fd_2$completers_prog_150pct)
fd_4$completers_prog_150pct = as.numeric(fd_4$completers_prog_150pct)

fd_fin = bind_rows(fd_2,
                   fd_4)
for(i in c("exclusions", "still_enrolled",
           "not_enrolled_anymore", "transfers")){
  fd_fin[[i]][which(is.na(fd_fin[[i]]))] = -3
}

fd_fin = fd_fin%>%
  rename(cohort_rev = rev_cohort,
         cohort_adj_150pct = adj_cohort,
         completers_150pct = completers_prog2_150pct,
         completers_100pct = completers_prog2_100pct,
         no_longer_enrolled = not_enrolled_anymore,
         still_enrolled_long_program = still_enrolled,
         completers_prog_2yr_sub_4yr_150pct = completers_prog_2yr_sub_4yr_150_pct,
         transfers_out= transfers,
         completers_bach_150pct_new = completers_bach3_150pct)%>%
  mutate(completion_rate_150pct = completers_150pct/cohort_adj_150pct)%>%
  select(-c(completers_prog_100pct,completers_prog_150pct))

for(i in c("completers_150pct", "completers_100pct",
           "completers_bach_150pct",
           "completers_bach_150pct_new",
           "completers_bach_100pct",
           "completion_rate_150pct",
           "completers_bach_5yr",
           "completers_bach_6yr",
           "completers_prog_2yr_sub_4yr_150pct",
           "completers_prog_sub_2yr_150pct",
           "completers_prog_sub_2yr_100pct",
           "completers_prog_2yr_sub_4yr_100pct")){
  fd_fin[[i]][which(is.na(fd_fin[[i]]))] = -3
}

fd_fin$cohort_year = NA
fd_fin$cohort_year[fd_fin$cohort%in%c(1,2,3)] = as.numeric(fd_fin$year[which(fd_fin$cohort%in%c(1,2,3))])-4
fd_fin$cohort_year[fd_fin$cohort%in%c(4,5)] = as.numeric(fd_fin$year[which(fd_fin$cohort%in%c(4,5))])-2

write_csv(fd_fin, paste0("Data/Output_Data/GR_1996_",current_year,"_3.csv"))